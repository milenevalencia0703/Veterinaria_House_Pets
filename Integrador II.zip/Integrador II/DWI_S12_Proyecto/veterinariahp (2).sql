-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-07-2022 a las 06:08:05
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `veterinariahp`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cita`
--

CREATE TABLE `cita` (
  `codcit` varchar(10) NOT NULL,
  `servcit` varchar(100) DEFAULT NULL,
  `hora` varchar(50) DEFAULT NULL,
  `fecha` varchar(50) DEFAULT NULL,
  `codcli` varchar(10) DEFAULT NULL,
  `codusu` varchar(10) DEFAULT NULL,
  `codmed` varchar(10) DEFAULT NULL,
  `codpag` varchar(10) NOT NULL DEFAULT '1',
  `codest` varchar(10) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `codcli` varchar(10) NOT NULL,
  `nomcli` varchar(50) DEFAULT NULL,
  `apecli` varchar(50) DEFAULT NULL,
  `emailcli` varchar(255) DEFAULT NULL,
  `dircli` varchar(255) DEFAULT NULL,
  `telcli` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`codcli`, `nomcli`, `apecli`, `emailcli`, `dircli`, `telcli`) VALUES
('', 'juan', 'dias', 'juan@gmail.com', 'av. la paz', '987654321');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (
  `codest` varchar(10) NOT NULL,
  `nomest` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`codest`, `nomest`) VALUES
('1', 'Pendiente'),
('2', 'Aplicada'),
('3', 'No asistio'),
('4', 'Cancelada'),
('1', 'Pendiente'),
('2', 'Aplicada'),
('3', 'No asistio'),
('4', 'Cancelada'),
('1', 'Pendiente'),
('2', 'Aplicada'),
('3', 'No asistio'),
('4', 'Cancelada'),
('1', 'Pendiente'),
('2', 'Aplicada'),
('3', 'No asistio'),
('4', 'Cancelada'),
('1', 'Pendiente'),
('2', 'Aplicada'),
('3', 'No asistio'),
('4', 'Cancelada'),
('1', 'Pendiente'),
('2', 'Aplicada'),
('3', 'No asistio'),
('4', 'Cancelada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascota`
--

CREATE TABLE `mascota` (
  `codmas` varchar(10) NOT NULL,
  `nommas` varchar(50) DEFAULT NULL,
  `razamas` varchar(50) DEFAULT NULL,
  `imgmas` varchar(255) DEFAULT NULL,
  `codcli` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medico`
--

CREATE TABLE `medico` (
  `codmed` varchar(10) NOT NULL,
  `nommed` varchar(50) DEFAULT NULL,
  `apemed` varchar(50) DEFAULT NULL,
  `emailmed` varchar(255) DEFAULT NULL,
  `telmed` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pago`
--

CREATE TABLE `pago` (
  `codpag` varchar(10) NOT NULL,
  `nompag` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pago`
--

INSERT INTO `pago` (`codpag`, `nompag`) VALUES
('1', 'Pendiente'),
('2', 'Pagado'),
('3', 'Anulado'),
('1', 'Pendiente'),
('2', 'Pagado'),
('3', 'Anulado'),
('1', 'Pendiente'),
('2', 'Pagado'),
('3', 'Anulado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `codusu` varchar(10) NOT NULL,
  `userusu` varchar(50) DEFAULT NULL,
  `emailusu` varchar(255) DEFAULT NULL,
  `passusu` varchar(60) DEFAULT NULL,
  `admusu` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cita`
--
ALTER TABLE `cita`
  ADD PRIMARY KEY (`codcit`),
  ADD KEY `pago_id` (`codpag`),
  ADD KEY `estado_id` (`codest`),
  ADD KEY `usuario_id` (`codusu`),
  ADD KEY `cliente_id` (`codcli`),
  ADD KEY `medico_id` (`codmed`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`codcli`);

--
-- Indices de la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD PRIMARY KEY (`codmas`),
  ADD KEY `codcli` (`codcli`);

--
-- Indices de la tabla `medico`
--
ALTER TABLE `medico`
  ADD PRIMARY KEY (`codmed`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`codusu`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cita`
--
ALTER TABLE `cita`
  ADD CONSTRAINT `cita_ibfk_1` FOREIGN KEY (`codcli`) REFERENCES `cliente` (`codcli`),
  ADD CONSTRAINT `cita_ibfk_2` FOREIGN KEY (`codmed`) REFERENCES `medico` (`codmed`),
  ADD CONSTRAINT `cita_ibfk_3` FOREIGN KEY (`codusu`) REFERENCES `usuario` (`codusu`);

--
-- Filtros para la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD CONSTRAINT `mascota_ibfk_1` FOREIGN KEY (`codcli`) REFERENCES `cliente` (`codcli`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
