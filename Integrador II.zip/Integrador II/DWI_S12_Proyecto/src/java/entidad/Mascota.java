/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ouya
 */
@Entity
@Table(name = "mascota")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Mascota.findAll", query = "SELECT m FROM Mascota m")
    , @NamedQuery(name = "Mascota.findByCodmas", query = "SELECT m FROM Mascota m WHERE m.codmas = :codmas")
    , @NamedQuery(name = "Mascota.findByNommas", query = "SELECT m FROM Mascota m WHERE m.nommas = :nommas")
    , @NamedQuery(name = "Mascota.findByTipmas", query = "SELECT m FROM Mascota m WHERE m.tipmas = :tipmas")})
public class Mascota implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "codmas")
    private Integer codmas;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "nommas")
    private String nommas;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "tipmas")
    private String tipmas;
    @JoinColumn(name = "codusu", referencedColumnName = "codusu")
    @ManyToOne(optional = false)
    private Usuario codusu;

    public Mascota() {
    }

    public Mascota(Integer codmas) {
        this.codmas = codmas;
    }

    public Mascota(Integer codmas, String nommas, String tipmas) {
        this.codmas = codmas;
        this.nommas = nommas;
        this.tipmas = tipmas;
    }

    public Integer getCodmas() {
        return codmas;
    }

    public void setCodmas(Integer codmas) {
        this.codmas = codmas;
    }

    public String getNommas() {
        return nommas;
    }

    public void setNommas(String nommas) {
        this.nommas = nommas;
    }

    public String getTipmas() {
        return tipmas;
    }

    public void setTipmas(String tipmas) {
        this.tipmas = tipmas;
    }

    public Usuario getCodusu() {
        return codusu;
    }

    public void setCodusu(Usuario codusu) {
        this.codusu = codusu;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codmas != null ? codmas.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mascota)) {
            return false;
        }
        Mascota other = (Mascota) object;
        if ((this.codmas == null && other.codmas != null) || (this.codmas != null && !this.codmas.equals(other.codmas))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidad.Mascota[ codmas=" + codmas + " ]";
    }
    
}
