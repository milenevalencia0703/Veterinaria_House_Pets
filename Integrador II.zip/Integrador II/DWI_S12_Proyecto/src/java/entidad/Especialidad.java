/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ouya
 */
@Entity
@Table(name = "especialidad")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Especialidad.findAll", query = "SELECT e FROM Especialidad e")
    , @NamedQuery(name = "Especialidad.findByCodesp", query = "SELECT e FROM Especialidad e WHERE e.codesp = :codesp")
    , @NamedQuery(name = "Especialidad.findByNomesp", query = "SELECT e FROM Especialidad e WHERE e.nomesp = :nomesp")})
public class Especialidad implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "codesp")
    private Integer codesp;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "nomesp")
    private String nomesp;
    @JoinColumn(name = "codmed", referencedColumnName = "codmed")
    @ManyToOne(optional = false)
    private Medico codmed;

    public Especialidad() {
    }

    public Especialidad(Integer codesp) {
        this.codesp = codesp;
    }

    public Especialidad(Integer codesp, String nomesp) {
        this.codesp = codesp;
        this.nomesp = nomesp;
    }

    public Integer getCodesp() {
        return codesp;
    }

    public void setCodesp(Integer codesp) {
        this.codesp = codesp;
    }

    public String getNomesp() {
        return nomesp;
    }

    public void setNomesp(String nomesp) {
        this.nomesp = nomesp;
    }

    public Medico getCodmed() {
        return codmed;
    }

    public void setCodmed(Medico codmed) {
        this.codmed = codmed;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codesp != null ? codesp.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Especialidad)) {
            return false;
        }
        Especialidad other = (Especialidad) object;
        if ((this.codesp == null && other.codesp != null) || (this.codesp != null && !this.codesp.equals(other.codesp))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidad.Especialidad[ codesp=" + codesp + " ]";
    }
    
}
