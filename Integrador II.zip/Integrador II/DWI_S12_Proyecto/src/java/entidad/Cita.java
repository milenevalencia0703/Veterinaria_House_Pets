/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ouya
 */
@Entity
@Table(name = "cita")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cita.findAll", query = "SELECT c FROM Cita c")
    , @NamedQuery(name = "Cita.findByCodcit", query = "SELECT c FROM Cita c WHERE c.codcit = :codcit")
    , @NamedQuery(name = "Cita.findByHoracit", query = "SELECT c FROM Cita c WHERE c.horacit = :horacit")
    , @NamedQuery(name = "Cita.findByFechacit", query = "SELECT c FROM Cita c WHERE c.fechacit = :fechacit")})
public class Cita implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "codcit")
    private Integer codcit;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "horacit")
    private String horacit;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechacit")
    @Temporal(TemporalType.DATE)
    private Date fechacit;
    @JoinColumn(name = "codusu", referencedColumnName = "codusu")
    @ManyToOne(optional = false)
    private Usuario codusu;
    @JoinColumn(name = "codmed", referencedColumnName = "codmed")
    @ManyToOne(optional = false)
    private Medico codmed;

    public Cita() {
    }

    public Cita(Integer codcit) {
        this.codcit = codcit;
    }

    public Cita(Integer codcit, String horacit, Date fechacit) {
        this.codcit = codcit;
        this.horacit = horacit;
        this.fechacit = fechacit;
    }

    public Integer getCodcit() {
        return codcit;
    }

    public void setCodcit(Integer codcit) {
        this.codcit = codcit;
    }

    public String getHoracit() {
        return horacit;
    }

    public void setHoracit(String horacit) {
        this.horacit = horacit;
    }

    public Date getFechacit() {
        return fechacit;
    }

    public void setFechacit(Date fechacit) {
        this.fechacit = fechacit;
    }

    public Usuario getCodusu() {
        return codusu;
    }

    public void setCodusu(Usuario codusu) {
        this.codusu = codusu;
    }

    public Medico getCodmed() {
        return codmed;
    }

    public void setCodmed(Medico codmed) {
        this.codmed = codmed;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codcit != null ? codcit.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cita)) {
            return false;
        }
        Cita other = (Cita) object;
        if ((this.codcit == null && other.codcit != null) || (this.codcit != null && !this.codcit.equals(other.codcit))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidad.Cita[ codcit=" + codcit + " ]";
    }
    
}
