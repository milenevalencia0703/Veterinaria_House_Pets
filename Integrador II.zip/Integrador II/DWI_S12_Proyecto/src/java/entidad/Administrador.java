/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Khervi
 */
@Entity
@Table(name = "administrador")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Administrador.findAll", query = "SELECT a FROM Administrador a")
    , @NamedQuery(name = "Administrador.findByNomadm", query = "SELECT a FROM Administrador a WHERE a.nomadm = :nomadm")
    , @NamedQuery(name = "Administrador.findByPasadm", query = "SELECT a FROM Administrador a WHERE a.pasadm = :pasadm")})
public class Administrador implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "nomadm")
    private String nomadm;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "pasadm")
    private String pasadm;

    public Administrador() {
    }

    public Administrador(String nomadm) {
        this.nomadm = nomadm;
    }

    public Administrador(String nomadm, String pasadm) {
        this.nomadm = nomadm;
        this.pasadm = pasadm;
    }

    public String getNomadm() {
        return nomadm;
    }

    public void setNomadm(String nomadm) {
        this.nomadm = nomadm;
    }

    public String getPasadm() {
        return pasadm;
    }

    public void setPasadm(String pasadm) {
        this.pasadm = pasadm;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (nomadm != null ? nomadm.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Administrador)) {
            return false;
        }
        Administrador other = (Administrador) object;
        if ((this.nomadm == null && other.nomadm != null) || (this.nomadm != null && !this.nomadm.equals(other.nomadm))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidad.Administrador[ nomadm=" + nomadm + " ]";
    }
    
}
