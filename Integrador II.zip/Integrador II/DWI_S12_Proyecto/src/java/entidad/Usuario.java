/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidad;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Ouya
 */
@Entity
@Table(name = "usuario")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Usuario.findAll", query = "SELECT u FROM Usuario u")
    , @NamedQuery(name = "Usuario.findByCodusu", query = "SELECT u FROM Usuario u WHERE u.codusu = :codusu")
    , @NamedQuery(name = "Usuario.findByNomusu", query = "SELECT u FROM Usuario u WHERE u.nomusu = :nomusu")
    , @NamedQuery(name = "Usuario.findByApeusu", query = "SELECT u FROM Usuario u WHERE u.apeusu = :apeusu")
    , @NamedQuery(name = "Usuario.findByTelusu", query = "SELECT u FROM Usuario u WHERE u.telusu = :telusu")
    , @NamedQuery(name = "Usuario.findByCorusu", query = "SELECT u FROM Usuario u WHERE u.corusu = :corusu")
    , @NamedQuery(name = "Usuario.findByPasusu", query = "SELECT u FROM Usuario u WHERE u.pasusu = :pasusu")
    , @NamedQuery(name = "Usuario.findByDirusu", query = "SELECT u FROM Usuario u WHERE u.dirusu = :dirusu")
    , @NamedQuery(name = "Usuario.findByFotusu", query = "SELECT u FROM Usuario u WHERE u.fotusu = :fotusu")
    , @NamedQuery(name = "Usuario.findByDniusu", query = "SELECT u FROM Usuario u WHERE u.dniusu = :dniusu")})
public class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "codusu")
    private Integer codusu;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "nomusu")
    private String nomusu;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "apeusu")
    private String apeusu;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "telusu")
    private String telusu;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "corusu")
    private String corusu;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "pasusu")
    private String pasusu;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "dirusu")
    private String dirusu;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "fotusu")
    private String fotusu;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 8)
    @Column(name = "dniusu")
    private String dniusu;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "codusu")
    private Collection<Mascota> mascotaCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "codusu")
    private Collection<Cita> citaCollection;

    public Usuario() {
    }

    public Usuario(Integer codusu) {
        this.codusu = codusu;
    }

    public Usuario(Integer codusu, String nomusu, String apeusu, String telusu, String corusu, String pasusu, String dirusu, String fotusu, String dniusu) {
        this.codusu = codusu;
        this.nomusu = nomusu;
        this.apeusu = apeusu;
        this.telusu = telusu;
        this.corusu = corusu;
        this.pasusu = pasusu;
        this.dirusu = dirusu;
        this.fotusu = fotusu;
        this.dniusu = dniusu;
    }

    public Integer getCodusu() {
        return codusu;
    }

    public void setCodusu(Integer codusu) {
        this.codusu = codusu;
    }

    public String getNomusu() {
        return nomusu;
    }

    public void setNomusu(String nomusu) {
        this.nomusu = nomusu;
    }

    public String getApeusu() {
        return apeusu;
    }

    public void setApeusu(String apeusu) {
        this.apeusu = apeusu;
    }

    public String getTelusu() {
        return telusu;
    }

    public void setTelusu(String telusu) {
        this.telusu = telusu;
    }

    public String getCorusu() {
        return corusu;
    }

    public void setCorusu(String corusu) {
        this.corusu = corusu;
    }

    public String getPasusu() {
        return pasusu;
    }

    public void setPasusu(String pasusu) {
        this.pasusu = pasusu;
    }

    public String getDirusu() {
        return dirusu;
    }

    public void setDirusu(String dirusu) {
        this.dirusu = dirusu;
    }

    public String getFotusu() {
        return fotusu;
    }

    public void setFotusu(String fotusu) {
        this.fotusu = fotusu;
    }

    public String getDniusu() {
        return dniusu;
    }

    public void setDniusu(String dniusu) {
        this.dniusu = dniusu;
    }

    @XmlTransient
    public Collection<Mascota> getMascotaCollection() {
        return mascotaCollection;
    }

    public void setMascotaCollection(Collection<Mascota> mascotaCollection) {
        this.mascotaCollection = mascotaCollection;
    }

    @XmlTransient
    public Collection<Cita> getCitaCollection() {
        return citaCollection;
    }

    public void setCitaCollection(Collection<Cita> citaCollection) {
        this.citaCollection = citaCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codusu != null ? codusu.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Usuario)) {
            return false;
        }
        Usuario other = (Usuario) object;
        if ((this.codusu == null && other.codusu != null) || (this.codusu != null && !this.codusu.equals(other.codusu))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidad.Usuario[ codusu=" + codusu + " ]";
    }
    
}
