package controlador;

import EJB.MedicoFacade;
import EJB.MedicoFacadeLocal;
import entidad.Medico;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

//3 aotaciones Beam administrado para que se vea en los JSF
@ManagedBean
@SessionScoped

public class ManagedMedico {
    @EJB//Enterprise java beams 
    MedicoFacadeLocal medicoFacadeLocal;
    private List<Medico>ListarMedico;
    private Medico medico;

    public List<Medico> getListarMedico() {// listar
        this.ListarMedico = this.medicoFacadeLocal.findAll();
        return ListarMedico;
    }

    public void setListarMedico(List<Medico> ListarMedico) {
        this.ListarMedico = ListarMedico;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }
    
    @PostConstruct
    public void init(){
        this.medico=new Medico();
    }
    public void guardarMedico(){//Insertar Medico
        this.medicoFacadeLocal.create(medico);
    }
    
    public void eliminarMedico(Medico m){//Eliminar Medico
        this.medicoFacadeLocal.remove(m);
    }
    
    public void cargarDatos(Medico m){
        this.medico=m;
    }
    
    public void modificarMedico(){
        this.medicoFacadeLocal.edit(medico);
    }
    
}