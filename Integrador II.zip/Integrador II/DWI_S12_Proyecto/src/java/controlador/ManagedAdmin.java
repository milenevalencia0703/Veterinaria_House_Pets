/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import EJB.AdministradorFacadeLocal;
import entidad.Administrador;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

/**
 *
 * @author Khervi
 */

@ManagedBean
@SessionScoped
public class ManagedAdmin {
    @EJB
    
    AdministradorFacadeLocal administradorFacadeLocal;
    private List<Administrador> listaAdministrador;
    private Administrador administrador;
    String verPagina;

    public List<Administrador> getListaAdministrador() {
        return listaAdministrador;
    }

    public void setListaAdministrador(List<Administrador> listaAdministrador) {
        this.listaAdministrador = listaAdministrador;
    }

    public Administrador getAdministrador() {
        return administrador;
    }

    public void setAdministrador(Administrador administrador) {
        this.administrador = administrador;
    }
    
    @PostConstruct
    public void init(){
        administrador = new Administrador(); 
    }
 
public String validarAdministrador(){
   listaAdministrador = administradorFacadeLocal.buscarAdministrador(administrador);
        if(!listaAdministrador.isEmpty()){
            //se crea session
            FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("user",administrador);
            verPagina = "index.xhtml";
        }
        else{
            FacesMessage mensaje = new FacesMessage("Usuario o contraseña invalido");
            FacesContext.getCurrentInstance().addMessage(null, mensaje);
        }
        return verPagina;
    }


public void obtenerSesion(){
 administrador = (Administrador)FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("user");
        if(administrador == null){
            try {
                FacesContext.getCurrentInstance().getExternalContext().redirect("/DWI_S12_Proyecto/faces/logueo.xhtml");
                init();
            } catch (IOException ex) {
                Logger.getLogger(ManagedAdmin.class.getName()).log(Level.SEVERE, null, ex);
            }
        }   
}
public void cerrarSesion(){
FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
}

/* public void cambiarIdioma(ValueChangeEvent e){
        System.out.println("ENTROOO");
        FacesContext fc = FacesContext.getCurrentInstance();
        UIViewRoot ui = fc.getViewRoot();
        ui.setLocale(new Locale(e.getNewValue().toString()));
        System.out.println("Pasooo");
    }*/
public void mostrarIdioma(ValueChangeEvent ev){
        FacesContext fc = FacesContext.getCurrentInstance();
        UIViewRoot ui = fc.getViewRoot();
        ui.setLocale(new Locale(ev.getNewValue().toString()));
    }
}

