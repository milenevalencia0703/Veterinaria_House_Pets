package controlador;

import EJB.MascotaFacadeLocal;
import entidad.Mascota;
import entidad.Usuario;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

//3 aotaciones Beam administrado para que se vea en los JSF
@ManagedBean
@SessionScoped

public class ManagedMascota {
    @EJB
    MascotaFacadeLocal mascotaFacadeLocal;
    private List<Mascota>ListarMascota;
    private Mascota mascota;
    private Usuario usuario;
    
    

    public List<Mascota> getListarMascota() {
        this.ListarMascota = this.mascotaFacadeLocal.findAll();
        return ListarMascota;
    }

    public void setListarMascota(List<Mascota> ListarMascota) {
        this.ListarMascota = ListarMascota;
    }

    public Mascota getMascota() {
        return mascota;
    }

    public void setMascota(Mascota mascota) {
        this.mascota = mascota;
    }
    
    
    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    @PostConstruct
    public void init(){
        this.mascota=new Mascota();
        this.usuario=new Usuario();
    }
    public void guardarMascota(){//Insertar Mascota
        this.mascota.setCodusu(usuario);
        this.mascotaFacadeLocal.create(mascota);
    }
    
    public void eliminarMascota(Mascota ma){//Eliminar Mascota
        this.mascota.setCodusu(usuario);
        this.mascotaFacadeLocal.remove(ma);
    }
    
    public void cargarDatos(Mascota ma){
        
        this.mascota.getNommas();
    }
    
    public void modificarMascota(){
        this.mascota.setCodusu(usuario);
        this.mascotaFacadeLocal.edit(mascota);
     
    }

    
}