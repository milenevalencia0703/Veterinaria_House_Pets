/*
Khervi la Torre
 */
package controlador;

import EJB.UsuarioFacadeLocal;
import entidad.Usuario;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped

public class ManagedUsuario {
    @EJB
    UsuarioFacadeLocal usuarioFacadeLocal;
    private List<Usuario>ListarUsuario;
    private Usuario usuario;

    public List<Usuario> getListarUsuario() {
        this.ListarUsuario = this.usuarioFacadeLocal.findAll();
        return ListarUsuario;
    }

    public void setListarUsuario(List<Usuario> ListarUsuario) {
        this.ListarUsuario = ListarUsuario;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    @PostConstruct
    public void init(){
        this.usuario=new Usuario();
    }
    public void guardarUsuario(){//Insertar 
        this.usuarioFacadeLocal.create(usuario);
    }
    
    public void eliminarUsuario(Usuario u){//Eliminar Medico
        this.usuarioFacadeLocal.remove(u);
    }
    
    public void cargarDatos(Usuario u){
        this.usuario=u;
    }
    
    public void modificarUsuario(){
        this.usuarioFacadeLocal.edit(usuario);
    }
    
}