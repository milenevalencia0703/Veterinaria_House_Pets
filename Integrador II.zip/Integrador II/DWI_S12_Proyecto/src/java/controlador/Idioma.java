
package controlador;

import java.util.Locale;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

public class Idioma {
    
    public Idioma() {
    }
    
    public void mostrarIdioma(ValueChangeEvent ev){
        FacesContext fc = FacesContext.getCurrentInstance();
        UIViewRoot ui = fc.getViewRoot();
        ui.setLocale(new Locale(ev.getNewValue().toString()));
    }
}
