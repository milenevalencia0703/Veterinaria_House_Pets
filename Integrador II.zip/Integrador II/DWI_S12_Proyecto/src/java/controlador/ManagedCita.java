package controlador;



import EJB.CitaFacadeLocal;
import entidad.Cita;
//import static entidad.Cita_.codcli;
//import entidad.Cliente;
import entidad.Medico;
import entidad.Usuario;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped

public class ManagedCita {
    @EJB
       //int id;
    //String cadena;
    CitaFacadeLocal citaFacadeLocal;
    private List<Cita>listarCita;
    private Cita cita;
    private Medico medico;
    private Usuario usuario;


    

    public List<Cita> getListarCita() {
        
        listarCita = this.citaFacadeLocal.findAll();
        return listarCita;
    }

    public void setListarCita(List<Cita> listarCita) {
        this.listarCita = listarCita;
    }

    public Cita getCita() {
        return cita;
    }

    public void setCita(Cita cita) {
        this.cita = cita;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
        
 
    //CONSTRUCTOR
    @PostConstruct
    public void init(){
        this.medico = new Medico();
        this.usuario = new Usuario();
        this.cita = new Cita();
    }
    //Guardar cita
    public  void guardarCita() {
        this.cita.setCodusu(usuario);
        this.cita.setCodmed(medico);
     this.citaFacadeLocal.create(cita);
     
    }
    //Eliminar Usuario
    public void eliminarCita(Cita c) {
        this.cita.setCodusu(usuario);
        this.cita.setCodmed(medico);
        this.citaFacadeLocal.remove(c);
    }
    //Cargar Datos
    public void cargarDatos(Cita c){
        this.medico.setCodmed(c.getCodmed().getCodmed());
        this.usuario.setCodusu(c.getCodusu().getCodusu());
        //cadena=Integer.toString(id);
        this.cita = c;
    }
    //Modificar cita
    public void modificarCita(){
        
        this.cita.setCodmed(medico);
        this.cita.setCodusu(usuario);
        this.citaFacadeLocal.edit(cita);
} 

  
}