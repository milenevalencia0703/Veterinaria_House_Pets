package controlador;

import EJB.EspecialidadFacadeLocal;
import EJB.MascotaFacadeLocal;
import entidad.Especialidad;
import entidad.Mascota;
import entidad.Medico;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped

public class ManagedEspecialidad {
    @EJB
    EspecialidadFacadeLocal especialidadFacadeLocal;
    private List<Mascota>ListarEspecialidad;
    private Especialidad especialidad;

    public List<Mascota> getListarEspecialidad() {
        return ListarEspecialidad;
    }

    public void setListarEspecialidad(List<Mascota> ListarEspecialidad) {
        this.ListarEspecialidad = ListarEspecialidad;
    }

    public Especialidad getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(Especialidad especialidad) {
        this.especialidad = especialidad;
    }
    
    @PostConstruct
    public void init(){
        this.especialidad=new Especialidad();
    }
    public void guardarEspecialidad(){//Insertar Medico
        this.especialidadFacadeLocal.create(especialidad);
    }
    
    public void eliminarEspecialidad(Especialidad e){//Eliminar Medico
        this.especialidadFacadeLocal.remove(e);
    }
    
    public void cargarDatos(Especialidad e){
        this.especialidad=e;
    }
    
    public void modificarEspecialidad(){
        this.especialidadFacadeLocal.edit(especialidad);
    }

    
    
}